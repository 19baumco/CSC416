//
//  ByeView.swift
//  baumgarthc1FirstApp
//
//  Created by Cooper Baumgarth on 1/28/22.
//

import SwiftUI

struct ByeView: View {
    var body: some View {
        Text("Bye bye, World!")
    }
}

struct ByeView_Previews: PreviewProvider {
    static var previews: some View {
        ByeView()
    }
}
