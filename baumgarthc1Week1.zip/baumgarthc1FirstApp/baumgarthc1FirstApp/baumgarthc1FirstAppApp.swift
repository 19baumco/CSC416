//
//  baumgarthc1FirstAppApp.swift
//  baumgarthc1FirstApp
//
//  Created by Cooper Baumgarth on 1/28/22.
//

import SwiftUI

@main
struct baumgarthc1FirstAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
