//
//  TaskModel.swift
//  ToDoList
//
//  Created by Cooper Baumgarth on 3/20/22.
//

import Foundation

struct TaskModel: Identifiable, Codable {
    let id: String
    let title: String
    let completed: Bool
    
    init(id: String = UUID().uuidString, title: String, completed: Bool) {
        self.id = id
        self.title = title
        self.completed = completed
    }
    
    func updateCompletion() -> TaskModel {
        return TaskModel(id: id, title: title, completed: !completed)
    }
}
