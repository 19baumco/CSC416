//
//  AddView.swift
//  ToDoList
//
//  Created by Cooper Baumgarth on 3/20/22.
//

import SwiftUI

struct AddView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var taskViewModel: TaskViewModel
    @State var textFieldText: String = ""
    
    var body: some View {
        ScrollView {
            VStack {
                TextField("Enter task here...", text: $textFieldText)
                    .frame(height: 50)
                    .padding(.horizontal)
                    .background(Color(red: 0.8, green: 0.8, blue: 0.8))
                    .cornerRadius(10)
                
                Button(action: saveButtonPress, label: {
                    Text("Save".uppercased())
                        .foregroundColor(.white)
                        .font(.headline)
                        .frame(height: 30)
                        .frame(maxWidth: .infinity)
                        .background(Color.accentColor)
                        .cornerRadius(10)
                })
            }.padding(14)
        }.navigationTitle("Add item")
    }
    
    func saveButtonPress() {
        if textLength() {
            taskViewModel.addItem(title: textFieldText)
            presentationMode.wrappedValue.dismiss()
        }
    }
    
    func textLength() -> Bool {
        if textFieldText.count < 1 {
            return false
        }
        return true
    }
}

struct AddView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AddView()
        }.environmentObject(TaskViewModel())
    }
}
