//
//  TaskRowView.swift
//  ToDoList
//
//  Created by Cooper Baumgarth on 3/20/22.
//

import SwiftUI

struct TaskRowView: View {
    let item: TaskModel
    
    var body: some View {
        HStack {
            Image(systemName: item.completed ? "checkmark.circle": "circle")
                .foregroundColor(item.completed ? .green: .red)
            Text(item.title)
        }
        .font(.title3)
        .padding(.vertical, 8)
    }
}

struct TaskRowView_Previews: PreviewProvider {
    static var item1 = TaskModel(title: "First Item", completed: false)
    static var item2 = TaskModel(title: "Second Item", completed: true)
    
    static var previews: some View {
        Group {
            TaskRowView(item: item1)
            TaskRowView(item: item2)
        }.previewLayout(.sizeThatFits)
    }
}
