//
//  TasksView.swift
//  ToDoList
//
//  Created by Cooper Baumgarth on 3/20/22.
//

import SwiftUI

struct TasksView: View {
    @EnvironmentObject var taskViewModel: TaskViewModel
    
    var body: some View {
        List {
            ForEach(taskViewModel.items) { item in
                TaskRowView(item: item)
                    .onTapGesture {
                        withAnimation(.linear) {
                            taskViewModel.updateItem(item: item)
                        }
                    }
            }
            .onDelete(perform: taskViewModel.deleteItem)
            .onMove(perform: taskViewModel.moveItem)
        }
        .listStyle(PlainListStyle())
        .navigationTitle("ToDo List")
        .navigationBarItems(
            leading: EditButton(),
            trailing:
                NavigationLink("Add", destination: AddView())
        )
    }
    
}

struct TasksView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            TasksView()
        }.environmentObject(TaskViewModel())
    }
}


