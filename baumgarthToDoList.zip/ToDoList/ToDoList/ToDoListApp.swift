//
//  ToDoListApp.swift
//  ToDoList
//
//  Created by Cooper Baumgarth on 3/20/22.
//

import SwiftUI

@main
struct ToDoListApp: App {
    @StateObject var taskViewModel: TaskViewModel = TaskViewModel()
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                TasksView()
            }.environmentObject(taskViewModel)
        }
    }
}
